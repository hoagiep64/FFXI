-- SCHOLAR --
function refresh_SCH()
	if displaySet == 1 then
		custom_SCH()
	elseif displaySet == 0 then
		--1-- Set
		Set_Display(1)
		--2-- Strategem
		Strategem_Display(2)
		--3-- Sublimation
		Ability_Display(3,234,188)
		--4-- Modus Veritas
		Ability_Display(4,230)
		--5-- Arts
		Arts_Display(5)
		--6-- Subjob
		Subjob_Display(6)
		Empty(7)
		Empty(8)
		Empty(9)
		Empty(10)
		
		
		--[[
		if Value4 == 'On' then
			color4 = Aero_col
		elseif Value4 == 'Off' then
			color4 = Fire_col
		end
		
		if Value3 == 'Stone' then
			color3 = Stone_col
		elseif Value3 == 'Water' then
			color3 = Water_col
		elseif Value3 == 'Aero' then
			color3 = Aero_col
		elseif Value3 == 'Fire' then
			color3 = Fire_col	
		elseif Value3 == 'Blizzard' then
			color3 = Blizzard_col
		elseif Value3 == 'Thunder' then
			color3 = Thunder_col
		elseif Value3 == 'Dark' then
			color3 = Dark_col
		elseif Value3 == 'Light' then
			color3 = Light_col
		end
		
		if Value3 == 'On' then
			color2 = Aero_col
		end--]]
	end
end