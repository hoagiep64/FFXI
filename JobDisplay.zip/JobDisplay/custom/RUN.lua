-- RUNEFENCER --
function custom_RUN() -- DO NOT ALTER THIS LINE
	
	--1-- Set
	Set_Display(1)
	--2-- Vivacious Pulse
	Ability_Display(2,242)
	--3-- One for All 
	Ability_Display(3,118,538)
	--4-- Swordplay
	Ability_Display(4,24,532)
	--5-- Refresh
	Buff_Display(5,43)
	--6-- Haste
	Buff_Display(6,33)
	--7-- Enspell
	Enspell_Display(7)
	--8-- Sub Jobs --
	Subjob_Display(8)		
	--9--
	Empty(9)
	--10-- 
	Empty(10)

end -- DO NOT ALTER THIS LINE